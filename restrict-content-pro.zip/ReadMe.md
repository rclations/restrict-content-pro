# [Restrict Content Pro](https://restrictcontentpro.com) #

[![Build Status](https://secure.travis-ci.org/restrictcontentpro/restrict-content-pro.png?branch=master)](https://travis-ci.org/restrictcontentpro/restrict-content-pro)

Restrict Content Pro is a commercial plugin available from [https://restrictcontentpro.com](https://restrictcontentpro.com). The plugin is hosted here on a public GitHub repository in order to better facilitate community contributions from developers and users alike. If you have a suggestion, a bug report, or a patch for an issue, feel free to submit it here. I do ask, however, that if you are using the plugin on a live site that you please purchase a valid license from the [website](https://restrictcontentpro.com). I cannot provide support to anyone that does not hold a valid license key.
